package cardealership;

import java.util.ArrayList;
import java.util.Scanner;

import personell.Customer;
import personell.Employee;
import user.User;
import user.UserUtil;
import utility.CustomerUtil;
import utility.EmployeeUtil;
import utility.SeriliazationUtility;

public class Main {

	public Employee loginEmployee;
	public User loginUser;
	public Customer loginCustomer;

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);

		System.out.println("***********************************************************");
		System.out.println("*********** Welcome to The Cloud Car Dealership ************");
		System.out.println("***********************************************************\n\n");
		System.out.println("Please Make a Choice");
		System.out.println("1 for  USERS   ");
		System.out.println("2 for  CUSTOMERS   ");
		System.out.println("3 for  EMPLOYEES   ");
		System.out.println("4 for  QUIT   ");

		// Lets create a boss as an employee and save the file for login
		// Saving object in a file
		String file = "employee.ser";

		// Employee(long employeeId, String userName, String password, String fName,
		// String lName, Contact contact)
		Employee boss = new Employee(1, "boss", "Password1", "Big", "Boss");
		ArrayList<Employee> employeeList = new ArrayList<Employee>();
		employeeList.add(boss);
		SeriliazationUtility.writeObjectList(file, employeeList);

		System.out.println("Object has been serialized"); 

	

		// This method reads the number provided using keyboard
		int selection = scan.nextInt();
		switch (selection) {

		case 1:
			System.out.println("You selected option 1 for USERS ");
			Main userSession = new Main();
			userSession.userLogin();

			break;
		case 2:
			System.out.println("You selected option 2 for CUSTOMERS");
			Main customerSession = new Main();
			customerSession.customerLogin();
			break;
		case 3:
			System.out.println("You selected option 3 for EMPLOYEES ");
			Main session = new Main();
			session.employeeLogin();

			break;
		case 4:
			System.out.println("You selected option 4 to QUIT ");
			System.exit(0);
			break;
		}

	}

	public void userLogin() {

		Main session = new Main();
		// Super User creation
		ArrayList<User> users = new ArrayList<User>();
		User su = new User("su", "su", "Super", "User");
		users.add(su);
		SeriliazationUtility.writeObjectList("user.ser", users);

		users = SeriliazationUtility.readObjectList("user.ser");

		Scanner sc = new Scanner(System.in);
		boolean flag = true;
		while (flag) {

			System.out.println("Enter  User Name:");
			String userNameEntry = sc.nextLine();
			System.out.println("Enter  Password:");
			String passwordEntry = sc.nextLine();

			// Verify list data and Boss credentials
			for (User user : users) {

				System.out.println(user);
				// Check for users for credentials
				if (user.getUserName().equalsIgnoreCase(userNameEntry) && user.getPassword().equals(passwordEntry)) {

					System.out.println("Login Successfull for " + user.getfName() + " " + user.getlName());

					session.loginUser = user;
					flag = false;
					break;
				} else {

					System.out.println("Wrong user name or password. Please try again.");
				}

			}
		}
		System.out.println("User Options, Please selct your choice");
		System.out.println("1- Register yourself for Customer Account");
		System.out.println("2- Quit");
		UserUtil userUtil = new UserUtil();
		userUtil.handleMenu(session.loginUser);
		sc.close();

	}

	public void employeeLogin() {

		Main session = new Main();
		ArrayList<Employee> employees = new ArrayList<Employee>();
		employees = SeriliazationUtility.readObjectList("employee.ser");

		Scanner sc = new Scanner(System.in);
		boolean flag = true;
		while (flag) {

			System.out.println("Enter Employee User Name:");
			String userNameEntry = sc.nextLine();
			System.out.println("Enter Employee Password:");
			String passwordEntry = sc.nextLine();

			// Verify list data and Boss credentials
			for (Employee employee : employees) {

				System.out.println(employee);
				// Check for users for credentials
				if (employee.getUserName().equalsIgnoreCase(userNameEntry)
						&& employee.getPassword().equals(passwordEntry)) {

					System.out.println("Login Successfull for " + employee.getfName() + " " + employee.getlName());

					session.loginEmployee = employee;
					flag = false;
					break;
				}

				else {

					System.out.println("Wrong user name or password. Please try again.");
				}

			}
		}
		System.out.println("Employee Options, Please selct your choice");
		System.out.println("1- Add car to the lot");
		System.out.println("2- Remove a car from the lot ");
		System.out.println("3- View Offers");
		System.out.println("4- View payments");
		System.out.println("5- Quit");
		EmployeeUtil employeeUtil = new EmployeeUtil();
		employeeUtil.handleMenu(session.loginEmployee);

		sc.close();

	}

	public void customerLogin() {

		Main sessionCustomer = new Main();
		ArrayList<Customer> customers = new ArrayList<Customer>();
		customers = SeriliazationUtility.readObjectList("customer.ser");

		Scanner sc = new Scanner(System.in);
		boolean flag = true;
		while (flag) {

			System.out.println("Enter  Customer User Name:");
			String userNameEntry = sc.nextLine();
			System.out.println("Enter  Password:");
			String passwordEntry = sc.nextLine();

			// Verify list data and Boss credentials
			for (Customer customer : customers) {

				// Check for users for credentials
				if (customer.getUser().getUserName().equalsIgnoreCase(userNameEntry)
						&& customer.getUser().getPassword().equals(passwordEntry)) {

					System.out.println("Login Successfull for " + customer.getUser().getfName() + " "
							+ customer.getUser().getlName());

					sessionCustomer.loginCustomer = customer;
					flag = false;
					break;
				} else {

					System.out.println("Wrong user name or password. Please try again.");
				}

			}
		}
		System.out.println("Customer Options, Please selct your choice");
		System.out.println("1- View the car lot");
		System.out.println("2- Make an offer for a car");
		System.out.println("3- Show my cars");
		System.out.println("4- Show my remaining payment");
		System.out.println("5- Quit");
		CustomerUtil customerUtil = new CustomerUtil();
		customerUtil.handleMenu(sessionCustomer.loginCustomer);
		sc.close();
	}

}
