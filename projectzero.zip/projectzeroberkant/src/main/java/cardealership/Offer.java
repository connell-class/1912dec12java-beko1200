package cardealership;

import java.io.Serializable;
import java.util.Date;

import personell.Customer;

public class Offer implements Serializable {



    /**
	 * 
	 */
	private static final long serialVersionUID = 5878014283253008207L;
	private Date offerDate;
    private Customer requestingCustomer;
    private Car requestedCar;
    private double offerPriceForRequestedCar;

    public Offer(Date offerDate, Customer requestingCustomer, Car requestedCar, double offerPriceForRequestedCar) {
    
        super();
        this.offerDate = offerDate;
        this.requestingCustomer = requestingCustomer;
        this.requestedCar = requestedCar;
        this.offerPriceForRequestedCar = offerPriceForRequestedCar;
    }

    public Date getOfferDate() {
    
        return offerDate;
    }

    public void setOfferDate(Date offerDate) {
    
        this.offerDate = offerDate;
    }

    public Customer getRequestingCustomer() {
    
        return requestingCustomer;
    }

    public void setRequestingCustomer(Customer requestingCustomer) {
    
        this.requestingCustomer = requestingCustomer;
    }

    public Car getRequestedCar() {
    
        return requestedCar;
    }

    public void setRequestedCar(Car requestedCar) {
    
        this.requestedCar = requestedCar;
    }

    public double getOfferPriceForRequestedCar() {
    
        return offerPriceForRequestedCar;
    }

    public void setOfferPriceForRequestedCar(double offerPriceForRequestedCar) {
    
        this.offerPriceForRequestedCar = offerPriceForRequestedCar;
    }

    @Override
    public String toString() {
    
        return "Offer [offerDate=" + offerDate + ", requestingCustomer=" + requestingCustomer + ", requestedCar=" + requestedCar + ", offerPriceForRequestedCar=" + offerPriceForRequestedCar + "]";
    }

}
