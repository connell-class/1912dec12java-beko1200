package cardealership;

import java.io.Serializable;

public class Car implements Serializable {

    
	private static final long serialVersionUID = 7461452400334034835L;
	private long carId;
    private short year;
    private String make;
    private String model;
    private double price;

    public Car(long carId, short year, String make, String model, double price) {
    
        super();
        this.carId = carId;
        this.year = year;
        this.make = make;
        this.model = model;
        this.price = price;
    }

    public long getCarId() {
    
        return carId;
    }

    public void setCarId(long carId) {
    
        this.carId = carId;
    }

    public short getYear() {
    
        return year;
    }

    public void setYear(short year) {
    
        this.year = year;
    }

    public String getMake() {
    
        return make;
    }

    public void setMake(String make) {
    
        this.make = make;
    }

    public String getModel() {
    
        return model;
    }

    public void setModel(String model) {
    
        this.model = model;
    }

    public double getPrice() {
    
        return price;
    }

    public void setPrice(double price) {
    
        this.price = price;
    }

    @Override
    public String toString() {
    
        return "Car [year=" + year + ", make=" + make + ", model=" + model + ", price=" + price + "]";
    }

}
