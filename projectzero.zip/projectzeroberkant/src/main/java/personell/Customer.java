package personell;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import cardealership.Car;
import cardealership.Offer;
import cardealership.Payment;
import user.User;
import utility.SeriliazationUtility;

public class Customer implements Serializable {

    private static final long serialVersionUID = 1L;
    private User user;
    private Set<Car> ownedCars;
    private ArrayList<Payment> payments;
    private Map<Car, Offer> offers;

    public Customer(User user) {
    
        super();
        this.user = user;
    }


    public User getUser() {
    
        return user;
    }

    public void setUser(User user) {
    
        this.user = user;
    }

    public Set<Car> getOwnedCars() {
    
        return ownedCars;
    }

    public void setOwnedCars(Set<Car> ownedCars) {
    
        this.ownedCars = ownedCars;
    }

    public ArrayList<Payment> getPayments() {
    
        return payments;
    }

    public void setPayments(ArrayList<Payment> payments) {
    
        this.payments = payments;
    }

    public Map<Car, Offer> getOffers() {
    
        return offers;
    }

    public void setOffers(Map<Car, Offer> offers) {
    
        this.offers = offers;
    }

    @Override
    public String toString() {
    
        return "Customer [user=" + user + "]";
    }


    public void viewCarLot() {
    

        Scanner sc = new Scanner(System.in);
        System.out.println("****** CAR LOT ******* ");
        ArrayList<Car> carList = new ArrayList<Car>();
        carList = SeriliazationUtility.readObjectList("lot.ser");

        for (Car car : carList) {
        
            System.out.println(carList.indexOf(car) + " CarID:" + car.getCarId() + " Year:" + car.getYear() + " MAKE:"
                + car.getMake() + " MODEL:" + car.getModel() + "  Price:  $" + car.getPrice());
        }
        
        sc.close();

    }

}
