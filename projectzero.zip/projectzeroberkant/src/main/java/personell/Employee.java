package personell;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;

import cardealership.Car;
import utility.SeriliazationUtility;

public class Employee implements Serializable {

    private static final long serialVersionUID = 1L;
    private long employeeId;
    private String userName;
    private String password;
    private String fName;
    private String lName;


    public Employee(long employeeId, String userName, String password, String fName, String lName) {
    
        super();
        this.employeeId = employeeId;
        this.userName = userName;
        this.password = password;
        this.fName = fName;
        this.lName = lName;

    }
    
    public void viewOffer() {
    	
    }

    public void addCar() {
    
        Scanner sc = new Scanner(System.in);
        System.out.println("Adding a car. Enter a Car ID: ");
        long carId = sc.nextLong();

        System.out.println("YEAR: ");
        short year = sc.nextShort();

        System.out.println("MAKE:");
        String make = sc.next();

        System.out.println("MODEL:");
        String model = sc.next();

        System.out.println("Price:");
        double price = sc.nextDouble();

        Car car = new Car(carId, year, make, model, price);
        ArrayList<Car> carList = new ArrayList<Car>();
        carList = SeriliazationUtility.readObjectList("lot.ser");
        carList.add(car);
        SeriliazationUtility.writeObjectList("lot.ser", carList);
        System.out.println("Added car and serialized");
        sc.close();

    }

    public void removeCar() {
    
        Scanner sc = new Scanner(System.in);
        System.out.println("Removing a car. Enter a Car ID: ");
        long carId = sc.nextLong();
        ArrayList<Car> carList = new ArrayList<Car>();
        carList = SeriliazationUtility.readObjectList("lot.ser");

        for (Car car : carList) {
        
            if (car.getCarId() == carId) {
            
                carList.remove(car);
                break;
            }
        }
        SeriliazationUtility.writeObjectList("lot.ser", carList);
        sc.close();
    }

    public long getEmployeeId() {
    
        return employeeId;
    }

    public void setEmployeeId(long employeeId) {
    
        this.employeeId = employeeId;
    }

    public String getUserName() {
    
        return userName;
    }

    public void setUserName(String userName) {
    
        this.userName = userName;
    }

    public String getPassword() {
    
        return password;
    }

    public void setPassword(String password) {
    
        this.password = password;
    }

    public String getfName() {
    
        return fName;
    }

    public void setfName(String fName) {
    
        this.fName = fName;
    }

    public String getlName() {
    
        return lName;
    }

    public void setlName(String lName) {
    
        this.lName = lName;
    }


    @Override
    public String toString() {
    
        return "Employee [employeeId=" + employeeId + ", userName=" + userName + ", fName=" + fName + ", lName=" + lName + "]";
    }

	public void viewPayment() {
		
		
	}


}
