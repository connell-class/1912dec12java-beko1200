package user;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;

import personell.Customer;
import utility.SeriliazationUtility;

public class User implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = -4572933338473242594L;
	private String userName;
    private String password;
    private String fName;
    private String lName;

    public User(String userName, String password, String fName, String lName) {
    
        super();
        this.userName = userName;
        this.password = password;
        this.fName = fName;
        this.lName = lName;
    }


    public String getUserName() {
    
        return userName;
    }

    public void setUserName(String userName) {
    
        this.userName = userName;
    }

    public String getPassword() {
    
        return password;
    }

    public void setPassword(String password) {
    
        this.password = password;
    }

    public String getfName() {
    
        return fName;
    }

    public void setfName(String fName) {
    
        this.fName = fName;
    }

    public String getlName() {
    
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }



    @Override
    public String toString() {
    
        return "user [fName=" + fName + ", lName=" + lName + "]";
    }

    public void register() {
    
        Scanner sc = new Scanner(System.in);
        System.out.println("To register you need to enter following information.");
        System.out.println("Please enter your  first name");
        String fname = sc.next();
        System.out.println("Please enter your  last name");
        String lname = sc.next();
        System.out.println("Please enter your  a user name");
        String userName = sc.next();
        System.out.println("Please enter your  a password");
        String password = sc.next();

        User user = new User(userName, password, fname, lname);
        Customer customer = new Customer(user);
        ArrayList<User> users = new ArrayList<User>();
        users.add(user);
        ArrayList<Customer> customers = new ArrayList<Customer>();
        customers.add(customer);
        SeriliazationUtility.writeObjectList("user.ser", users);
        SeriliazationUtility.writeObjectList("customer.ser", customers);
        System.out.println(user.fName + " " + user.lName + "  serialized and customer registered.");
 
		sc.close();

    }

}
