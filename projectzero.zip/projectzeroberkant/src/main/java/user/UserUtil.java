package user;

import java.util.Scanner;

public class UserUtil {

	public void handleMenu(User loginUser) {

		Scanner scan = new Scanner(System.in);
		int selection = scan.nextInt();
		switch (selection) {
		case 1:
			System.out.println("You selected option 1 for Add car to the lot ");
			loginUser.register();
			break;
		case 2:
			System.out.println("You selected option 2 for Quit ");
			System.exit(0);
			break;

		}
		scan.close();
	}
}
