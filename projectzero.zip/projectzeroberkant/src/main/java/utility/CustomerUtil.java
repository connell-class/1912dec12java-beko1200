package utility;

//import java.util.ArrayList;
import java.util.Scanner;
//import java.util.Set;

import personell.Customer;

public class CustomerUtil{



	public void handleMenu(Customer loginUser) {

		Scanner scan = new Scanner(System.in);
		int selection;

		do {

			// This method reads the number provided using keyboard
			selection = scan.nextInt();
			switch (selection) {
			case 1:
				System.out.println("You selected option 1 for View car lot ");
				loginUser.viewCarLot();
				break;
			case 2:
				System.out.println("You selected option 2 for Make an offer ");
				// // ask customer for carID(car Id = scan . nextint()),
//                bid price, (bid price = scan . nextint()),
//                look up car by carId (iterate through car list and see if car matches carId)
//                add bid to car
				break;

			case 3:
				System.out.println("You selected option 3 Show my cars ");
				// iterate through (private Set<Car> ownedCars;)
				// loginuser.getOwnedCars
				break;

			case 4:
				System.out.println("You selected option 4 for Remaining Payment");
				// iterate through (private ArrayList<Payment> payments;)

				break;
			case 5:
				System.out.println("You selected option 5 QUIT");
				System.exit(0);
				break;
			}

		} while (selection < 6);
		
		scan.close();
	}
}
