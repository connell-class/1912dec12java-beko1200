package utility;

import java.util.Scanner;

import personell.Employee;

public class EmployeeUtil {


    public void handleMenu(Employee loginEmployee) {
    

        Scanner scan = new Scanner(System.in);
     // This method reads the menu option selection
        int selection = scan.nextInt();
        switch (selection) {
        
            case 1:
                System.out.println("You selected option 1 for Add car to the lot ");
                loginEmployee.addCar();
                break;
            case 2:
                System.out.println("You selected option 2 for Remove a car from the lot  ");
                loginEmployee.removeCar();
                break;
                
            case 3:
                System.out.println("You selected option 3 for View Offers  ");
                loginEmployee.viewOffer();
                break;
            case 4:
                System.out.println("You selected option 3 for View Payments  ");
                loginEmployee.viewPayment();
                break;
                
            case 5:
                System.exit(0);
                break;
        
    }
        scan.close();


}

} 
