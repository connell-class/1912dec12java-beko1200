package utility;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class SeriliazationUtility {


    static void writeObject(String file, Object o) {
    
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
        

            oos.writeObject(o);
        }
        catch (IOException e){
        
            System.out.println("Writing object problem");
            e.printStackTrace();
        }

    }

    static Object readObject(String file) {
    
        try (ObjectInputStream is = new ObjectInputStream(new FileInputStream(file))) {
        

            return is.readObject();

        }
        catch (IOException e) {
        
            e.printStackTrace();
        }
        catch (ClassNotFoundException e) {
        
            e.printStackTrace();

        }
        return null;
    }

    public static <T> void writeObjectList(String file, ArrayList<T> o) {
    

        try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(file))) {
        

            os.writeObject(o);

        }
        catch (IOException e) {
        
            e.printStackTrace();
        }

    }

    @SuppressWarnings("unchecked")
	public
    static <T> ArrayList<T> readObjectList(String file) {
    
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
        
            return (ArrayList<T>) ois.readObject();
        }
        catch (Exception e) {
        
            System.out.println("Problem reading the file!..");
            return null;

        }
    }

}
